@extends('admin.main-dashboard-frame')

@section('admin-content')
    <div class="container-fluid">
        <!-- Page Heading -->
        <!-- Content Row -->
        <div class="row">
            <div class="col-md-12 mb-3">
                <div class="card rounded-0">
                    <div class="card-header rounded-0 py-2 bg-dark text-light font-weight-bolder">
                    All Advertisements
                    </div>
                    <div class="card-body pb-0">
                        <style>
                            td {
                                padding: 4px !important;
                                font-size: 14px !important;
                            }

                            td p {
                                font-size: 14px !important;
                                padding: 0px !important;
                                margin: 0px !important;
                            }
                        </style>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped " id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Sender Name</th>
                                        <th>Sender Email</th>
                                        <th>Mobile</th>
                                        <th>Subject</th>
                                        <th>Message</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td class="align-middle">1</td>
                                        <td class="align-middle">
                                            Anjali Kapoor
                                        </td>

                                        <td class="align-middle">
                                            anjalitest@gmail.com
                                        </td>
                                        <td class="align-middle">
                                            9898858744
                                        </td>
                                        <td class="align-middle">
                                            This App Gets Us Bitc0in…
                                        </td>
                                        <td class="align-middle">
                                            <p style="width: 12rem;">
                                                Hey wbg24.com Would you like to get some Bitc <a href="">Read More</a>
                                            </p>
                                        </td>
                                        <td class="align-middle">
                                            2023-07-27
                                        </td>
                                        <td class="align-middle">
                                            <a href="" class="btn m-1 btn-sm btn-info"><i class="fas fa-envelope    "></i></a>
                                            
                                            <a href="" class="btn m-1 btn-sm btn-primary"><i class="fas fa-trash    "></i></a>

                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection

@section('custom-js')
@endsection
